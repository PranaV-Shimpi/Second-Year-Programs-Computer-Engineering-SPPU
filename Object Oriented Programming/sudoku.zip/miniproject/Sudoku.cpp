#include"generator.h"
#include<cstring>
// #pragma comment(lib, "user32")
using namespace std;
bool gameEnd,upercase;
const int Max = 9;
int ans=0,check,r=5,s=40;	//r,s for x-y location

int level=1;
const int GRAY=247;
const int BROWN=244;
const int WHITE=15;
const int GREEN=10;
const int UP=72;
const int DOWN=80;
const int ENTER=13;
const int RED=140;
const int GREEN_GRAYBACK=138;
const int BROWN_GRAYBACK=132;
const int YELLOW_GRAYBACK=142;
const int BLUE_WHITEBACK=241;

char g;
int q,w;
int a[Max][Max],b[Max][Max],u[Max][Max][4];
int z[Max][Max];

void SetWindow(int Width, int Height) 
{ 
	_COORD coord; 
	coord.X = Width; 
	coord.Y = Height; 

	_SMALL_RECT Rect; 
	Rect.Top = 0; 
	Rect.Left = 0; 
	Rect.Bottom = Height - 1; 
	Rect.Right = Width - 1; 

	// Get handle of the standard output 
	HANDLE Handle = GetStdHandle(STD_OUTPUT_HANDLE); 
 
	// Set screen buffer size to that specified in coord 
	SetConsoleScreenBufferSize(Handle, coord);

	// Set the window size to that specified in Rect 
	SetConsoleWindowInfo(Handle, TRUE, &Rect);
} 

void ShowConsoleCursor(bool showFlag)
{
	HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_CURSOR_INFO     cursorInfo;

	GetConsoleCursorInfo(out, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(out, &cursorInfo);
}
void gotoxy(int x, int y)
{
	static HANDLE h = NULL;  
	if(!h)
	h = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD c ;  
	c.X=y;
	c.Y=x;
	SetConsoleCursorPosition(h,c);
}
void color(int i)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),i);
}
int valid(int u,int v)
{
	if(a[u][v])
	{
		for (int i=u,j=0;j<Max;j++)
			if((a[u][v]==a[i][j])&&(j!=v))
				return 0;
			
		for (int j=v,i=0;i<Max;i++)
			if((a[u][v]==a[i][j])&&(i!=u))
				return 0;

		for(int i=u/3*3,k=0;k<3;k++,i++)
			for(int j=v/3*3,k=0;k<3;k++,j++)
				if((a[u][v]==a[i][j]) && !(i==u && j==v))
					return 0;
	}
	return 1;
}
void set_cursor(int i,int j)
{
	q=i;
	w=j;
}
void cursor(int i,int j)
{
	if(q==i && w==j)
	{
		color(BROWN_GRAYBACK);
		if(!z[q][w])
		{
			if(valid(q,w))
				color(GREEN_GRAYBACK);
			else
				color(RED);
		}
	}
	else
	{
		if(z[i][j])
			color(BROWN);
		else
			color(BLUE_WHITEBACK);
	}
}
void uper_cursor(int i,int j)
{
	if(q==i && w==j)
	{
		color(YELLOW_GRAYBACK);
	}
	else
		color(246);
}
void draw_box()
{
	r=5;s=40;
	color(BROWN);
	gotoxy(r,s);
	cout<<" _____________________________________________________ ";
	color(WHITE);
		gotoxy(++r,s);

	
		for(int j=1;j<=3;j++)
		{
			color(BROWN);
			cout<<"|     |     |     |     |     |     |     |     |     |";
				gotoxy(++r,s);

		}
				
		for(int i=1;i<=8;i++)
		{
			cout<<"|-----|-----|-----|-----|-----|-----|-----|-----|-----|";
			color(WHITE);
				gotoxy(++r,s);

			for(int j=1;j<=3;j++)
			{
				color(BROWN);
				cout<<"|     |     |     |     |     |     |     |     |     |";
					gotoxy(++r,s);

			}
	
			}
		color(BROWN);
		cout<<"|_____|_____|_____|_____|_____|_____|_____|_____|_____|"<<endl;
	for (int i = 0,r=6; i < 3; i++,r=r+12)
	{
		for (int j = 0,s=41; j < 3; j++,s=s+18)
		{
			color(GRAY);
			int k=0;
			for(int l=1;l<=3;l++)
			{
				gotoxy(r+k,s);
				cout<<"     |     |     \n";
				k++;
			}
			gotoxy(r+k,s);
			cout<<"-----|-----|-----\n";
			k++;
			for(int l=1;l<=3;l++)
			{
				gotoxy(r+k,s);
				cout<<"     |     |     \n";
				k++;
			}
			gotoxy(r+k,s);
			cout<<"-----|-----|-----\n";
			k++;
			for(int l=1;l<=3;l++)
			{
				gotoxy(r+k,s);
				cout<<"     |     |     \n";
				k++;
			}
			gotoxy(r+k,s);
			if(i<2)
			{
				color(BROWN);
				cout<<"-----";
				color(GRAY);
				cout<<"|";
				color(BROWN);
				cout<<"-----";
				color(GRAY);
				cout<<"|";
				color(BROWN);
				cout<<"-----";
			}
			else
			{	
				color(BROWN);
				cout<<"_____";
				color(GRAY);
				cout<<"|";
				color(BROWN);
				cout<<"_____";
				color(GRAY);
				cout<<"|";
				color(BROWN);
				cout<<"_____|";
			}
		}
	}
	for (int i = 0,r=6; i < 9; i++,r=r+4)
	{
		for (int j = 0,s=41; j < 9; j++,s=s+6)
		{
			gotoxy(r,s);
			cursor(i,j);
			if(a[i][j])
			{
				cout<<"     ";
				gotoxy(r+1,s);
				cout<<"  "<<z[i][j]<<"  ";
				gotoxy(r+2,s);
				cout<<"     ";
			}
			else
			{
				cout<<"     ";
				gotoxy(r+1,s);
				cout<<"     ";
				gotoxy(r+2,s);
				cout<<"     ";
			}
			color(WHITE);
		}
	}
	color(WHITE);
}
void draw()
{
	for (int i = 0,r=6; i < Max; i++,r=r+4)
	{
		for (int j = 0,s=41; j < Max; j++,s=s+6)
		{
				gotoxy(r,s);
				cursor(i,j);
				if(a[i][j])
				{
					cout<<"     ";
					gotoxy(r+1,s);
					cout<<"  "<<a[i][j]<<"  ";
					gotoxy(r+2,s);
					cout<<"     ";
				}
				else
				{
					cout<<"     ";
					gotoxy(r+1,s);
					cout<<"     ";
					gotoxy(r+2,s);
					cout<<"     ";
				}
				color(WHITE);
		}
	}
	for (int i = 0,r=6; i < Max; i++,r=r+4)
	{
		for (int j = 0,s=41; j < Max; j++,s=s+6)
		{
			uper_cursor(i,j);
			gotoxy(r,s);
			if(u[i][j][0])
			{
				cout<<u[i][j][0];
			}
			gotoxy(r,s+4);
			if(u[i][j][1])
			{
				cout<<u[i][j][1];
			}
			gotoxy(r+2,s);
			if(u[i][j][2])
			{
				cout<<u[i][j][2];
			}
			gotoxy(r+2,s+4);
			if(u[i][j][3])
			{
				cout<<u[i][j][3];
			}
				color(WHITE);
		}
	}
	color(WHITE);
}
int is_full()
{
	int k=0;
	for(int i=0;i<Max;i++)
		for(int j=0;j<Max;j++)
			if(a[i][j])
				k++;
	if(k==81)
		return 1;
	return 0;
}

int resume()
{
	char line[120];
	ifstream in("resume.txt");
	int flag=0;
	while(in.peek() != std::ifstream::traits_type::eof())
	{
		in.getline(line,120);
		flag=1;
		int pos=0;
		for (int i = 0; i < 9; ++i)
			for (int j = 0; j < 9; ++j)
				z[i][j]=line[pos++]-'0';
		break;
	}
	
	in.close();
	if(flag==0)
	{
		cout<<"No saved game\n\nPress Enter to goto menu";
		getch();
	}
	system("cls");
	return flag;

}

void save()
{
	system("cls");
	ofstream out("resume.txt");
	for(int i=0;i<Max;i++)
		for(int j=0;j<Max;j++)
			out<<a[i][j];
	out<<endl;
	out.close();
	cout<<"\nYour game has been saved!\nPress Enter to goto menu";
	getch();
	system("cls");
}


int win()
{
	if(is_full())
	{
		draw();
		Sleep(300);
		color(GREEN);
		cout<<"\n\n\n\t\t\t\t\t  :: [ YOU WON THE GAME ] ::";
		color(WHITE);
		gameEnd=true;
		getch();
		return 1;
	}
	return 0;
}
void help()
{
	gotoxy(5,40);
	color(11);
	cout<<"\n\t\t\t\t==============================================";
	cout<<"\n\t\t\t\t                     HELP                     ";
	cout<<"\n\t\t\t\t==============================================";
	cout<<"\n\n\t\t\t\tUse w,a,s,d or arrow keys to navigate";
	cout<<"\n\n\t\t\t\tPress space to save game and return to Menu";
	cout<<"\n\n\t\t\t\tPress h to get a hint";
	cout<<"\n\n\t\t\t\tPress Enter to continue";
	getch();
	color(WHITE);
	system("cls");	
}
void about()
{
	gotoxy(5,40);
	color(11);
	cout<<"\n\t\t\t\t================================================";
	cout<<"\n\t\t\t\t                     SUDOKU                    ";
	cout<<"\n\t\t\t\t================================================";
	cout<<"\n\n\t\t\t\tSudoku is a number placement puzzle.";
	cout<<"\n\n\t\t\t\tThe objective is to fill a 9x9 grid with digits,";
	cout<<"\n\t\t\t\tso that each column, each row, and each of the nine";
	cout<<"\n\t\t\t\t3x3 subgrids that compose the grid (also called \"boxes\"";
	cout<<"\n\t\t\t\tcontains all of the digits from 1 to 9. ";
	cout<<"\n\n\t\t\t\tPress Enter to continue";
	getch();
	color(WHITE);
	system("cls");	
}

void loading()
{
	color(4);
	string start,load;
	r=5;
	gotoxy(r,40);
	for (int i = 0; i < 40; i++)
	{
		cout<<"=";
		Sleep(80);
	}
	start="                  SUDOKU             ";
	r++;
	gotoxy(r,40);
	color(11);
	for (int i = 0; i < start.length(); i++)
	{
		cout<<start[i];
		Sleep(80);
	}
	r++;
	gotoxy(7,40);
	color(4);
	for (int i = 0; i < 40; i++)
	{
		cout<<"=";
		Sleep(80);
	}	
	r+=2;
	gotoxy(r,40);
	color(11);
	cout<<"Loading...";
	r+=2;
	gotoxy(r,40);
	color(4);
	for (int i = 0; i < 40; i++)
	{
		cout<<"=";
		Sleep(80);
	}
	system("cls");
}

int menu()
{
	int j=0,i=1;
	while(j!=ENTER)
	{
			r=5;
			color(WHITE);
			r+=2;
			gotoxy(r,38);
			if(i==1)
			{
				color(GREEN);
				gotoxy(r,38);
				cout<<"--> ";
			}			
			cout<<"Resume";									//menu 1
			color(WHITE);
			r+=2;
			gotoxy(r,38);
			if(i==2)
			{
				color(GREEN);
				gotoxy(r,38);
				cout<<"--> ";
			}
			
			cout<<"START";									//menu 2
			r+=2;
			gotoxy(r,38);
			color(WHITE);
			if(i==3)
			{
				color(GREEN);
				gotoxy(r,38);
				cout<<"--> ";
			}
			cout<<"HELP";									//menu 3
			r+=2;
			gotoxy(r,38);
			color(WHITE);
			if(i==4)
			{
				color(GREEN);
				gotoxy(r,38);
				cout<<"--> ";
			}
			cout<<"ABOUT";									//menu 4
			r+=2;
			gotoxy(r,38);
			color(WHITE);
			if(i==5)
			{
				color(GREEN);
				gotoxy(r,38);
				cout<<"--> ";
			}
			cout<<"EXIT\n";									//menu 5
			
			color(WHITE);
			gotoxy(20,0);
			j=getch();
			if(j==DOWN)
				{i++;}
			else if(j==UP)
				{i--;}
			if(i==6) i=1;	// to cycle through menu
			if(i==0) i=5;
			system("cls");
	}

	if(i==1)
	{
		ans=2;
		return 2;
	}
	if(i==2)
	{
		ans=1;
		return 1;
	}
	if(i==3)
	{
		help();
		menu();
	}
	if(i==4)
	{
		about();
		menu();
	}
	if(i==5) _Exit(0);
}

int input()
{
	g=getch();
	check=0;

	if (g)
	{
		if(g==' ')
		{
			cout<<"Game is saved\n";
			save();
			return 1;
		}
		if(g=='h')
		{
			hint(a);
			return 0;
		}
		switch (g)
		{
			case 'w':
			case 72:
				q=q-1;
				if(q==9)
					q=0;
				if(q==-1)
					q=8;
				break;
			case 's':
			case 80:
				q=q+1;
				if(q==9)
					q=0;
				if(q==-1)
					q=8;
				break;
			case 'a':
			case 75:
				w=w-1;
				if(w==9)
					w=0;
				if(w==-1)
					w=8;
				break;
			case 'd':
			case 77:
				w=w+1;
				if(w==9)
					w=0;
				if(w==-1)
					w=8;
				break;
			case '0':
				if(upercase)
					upercase=false;
				else
					upercase=true;
				break;
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				if(upercase)
				{
					if(!z[q][w])
					{
						int k,j=0;
						k=g-'0';
						for (int i = 0; i < 4; ++i)
						{
							if(u[q][w][i])
							{
								if(u[q][w][i]==k)
								{
									u[q][w][i]=0;
									for(int h=i;h<4;h++)
									{
										u[q][w][h]=u[q][w][h+1];
										u[q][w][h+1]=0;
									}
									break;
								}
								j++;
							}
							else
							{
								u[q][w][i]=k;
								break;
							}
						}
						if(j==4)
						{
							if(u[q][w][3])
							{
								u[q][w][3]=k;
								break;
							}
						}
					}
				}
				else
				{
					if(!z[q][w])
					{
						int k;
						k=g-'0';
						if(a[q][w]==k)
							a[q][w]=0;
						else
							a[q][w]=k;
					}
				}
				break;
			case 'p':
				store(b,z);
				solver(b);
				store(a,b);
				break;
			default :
				input();
				break;
		}
		return 2;
	}
	return 0;
}

int play_again()
{
	system("cls");
	int j=0,i=1;
	while(j!=ENTER)
	{
			color(WHITE);
			cout<<"\n\n\n\n\t\t\t\t\t";
			if(i==1)
			{
				color(GREEN);
				cout<<"--> ";
			}
			cout<<"Replay\n\n\t\t\t\t\t";
			color(WHITE);
			if(i==2)
			{
				color(GREEN);
				cout<<"--> ";
			}
			cout<<"EXIT"<<endl;
			j=getch();
			if(j==DOWN)
				i++;
			else if(j==UP)
				i--;
			if(i==3)
				i=1;
			if(i==0)
				i=2;
			system("cls");
	}
	if(i==1)
	{
		gameEnd=false;
			return 1;
	}
	else
		return 0;
}
void reset()
{
	for(int i=0;i<Max;i++)
		for(int j=0;j<Max;j++)
		{
			u[i][j][0]=0;
			u[i][j][1]=0;
			u[i][j][2]=0;
			u[i][j][3]=0;
			a[i][j]=z[i][j];
		}
}
void play()
{
	int answer=1;
	while(answer)
	{
		reset();
		set_cursor(0,0);

		draw_box();
		while(true)
		{
			gameEnd=false;
			ShowConsoleCursor(false);
			draw();
			if(win()) break;
			int x=input();
			if(x==1)
				break;
			if(win()) break;
		}

		answer=play_again();
	}	
}


int diffmenu()
{
	system("cls");
	int j=0,i=1;
	while(j!=ENTER)
	{
			color(WHITE);			// to reset color
			cout<<"\n\n\n\n\t\t\t\t\t";
			if(i==1) 
			{
				color(GREEN);
				cout<<"--> ";
			}
			cout<<"Easy\n\n\t\t\t\t\t";
			color(WHITE);
			if(i==2) 
			{
				color(GREEN);
				cout<<"--> ";
			}
			cout<<"Medium\n\n\t\t\t\t\t";
			color(WHITE);
			if(i==3) 
			{
				color(GREEN);
				cout<<"--> ";
			}
			cout<<"Hard";

			j=getch();
			if(j==DOWN) i++;
			else if(j==UP) i--;
			if(i==4) i=1;
			if(i==0) i=3;
			system("cls");
	}
	return i;
}


void difficulty()
{
	int i,j,n;
	level=diffmenu();
	if(level==1) n=rand()%3+40;	// easy
	if(level==2) n=rand()%3+55;	// medium
	if(level==3) n=rand()%3+65;	// hard
	for (int k = 0; k < n; ++k)	// to remove n digits
	{
		i=rand()%9;
		j=rand()%9;
		z[i][j]=0;
	}
	level++;
}

int main()
{
	SetWindow(100,50);
	system("cls");
	loading();
	srand(time(NULL));
	upercase=false;
	ShowConsoleCursor(false);
	int answer=1;
	while(answer!=0)
	{	
		answer=menu();
		if(answer==1)
		{
			generate(z);	// generate random sudoku board
			difficulty();	// set difficulty of sudoku
			draw_box();
			play();
		}
		else if(answer==2)
		{
			if(resume()==1) // saved game present
			{
				draw_box();
				play();
			}
		}
	}
	return 0;
}