#include "solver.h"

void generatediag(int a[9][9])
{
	int start=0;			//start position of row,col
	int x,y;
	srand(time(NULL));		//update seed value for more randomness
	for (int k = 0; k < 3; k++) {
	  for (int j = 1; j <=9; j++) {
		x=rand()%3+start;
		y=rand()%3+start;
		if (a[x][y]==0)
		  a[x][y]=j;
		else
		  j--;            //to add in another block
	}
	  start+=3;           //add random nos in block
	}
}

void generate(int a[9][9])
{
	for (int i = 0; i < 9; ++i)		//setting matrix to zeroes
		for (int j = 0; j < 9; ++j)
			a[i][j]=0;
	generatediag(a);			//to generate diagonal boxes

	solver(a);

	
}					//add class here

