#include <iostream>
#include<conio.h>
#include<windows.h>
#include <ctime>
#include<fstream>
const int MAX=9;
using namespace std;

int hintenable=0;
void hint(int a[MAX][MAX]);

void store(int backup[MAX][MAX],int array[MAX][MAX])
{
	for(int i=0;i<MAX;i++)
		for(int j=0;j<MAX;j++)
			backup[i][j]=array[i][j];
}
void display(int g[MAX][MAX])
{
	for (int i=0;i<MAX;i++)
	{
		for (int j=0;j<MAX;j++)
		{
			cout<<g[i][j]<<" ";
		}
		cout<<endl;
	}
}
int find_zero(int g[MAX][MAX], int &i, int &j)
{
	for (i = 0; i < MAX; i++)
		for (j = 0; j < MAX; j++)
			if (g[i][j] == 0)
				return 1;
	return 0;
}
int row(int g[MAX][MAX], int i, int k)
{
	for (int j = 0; j < MAX; j++) 
		if (g[i][j] == k)
			return 1;
	return 0;
}
int col(int g[MAX][MAX], int j, int k)
{
	for (int i = 0; i < MAX; i++)
		if (g[i][j] == k)
			return 1;
	return 0;
}
int box(int g[MAX][MAX], int row, int col, int k)
{
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (g[i+row][j+col] == k)
				return 1;
	return 0;
}
int isvalid(int g[MAX][MAX], int i, int j, int k)
{
	return !row(g, i, k) &&
		   !col(g, j, k) &&
		   !box(g, i-i%3, j-j%3, k);
}
int solvable(int k[MAX][MAX])
{
	int g[MAX][MAX];
	store(g,k);
	int i, j;
	if (!find_zero(g, i, j))
	   return 1;
	for (int k = 1; k <= 9; k++)
	{
		if (isvalid(g, i, j, k))
		{
			g[i][j] = k;
			if (solvable(g))
				return 1;
			g[i][j] = 0;
		}
	}
	return 0;
}

int solver(int g[MAX][MAX])
{
	int i, j;
	if (!find_zero(g, i, j))
	   return 1;
	for (int k = 1; k <= 9; k++)
	{
		if (isvalid(g, i, j, k))
		{
			g[i][j] = k;
			if (solver(g))
				return 1;
			g[i][j] = 0;
			if(g[i][j]!=0 && hintenable==1)
				hint(NULL);
		}
	}
	return 0;
}

void hint(int a[MAX][MAX])
{
	hintenable=1;
	if(a==NULL) return;
	int b[MAX][MAX],i,j;
	store(b,a);

	find_zero(b, i, j);
	int ans=solver(b);
	a[i][j]=b[i][j];
}